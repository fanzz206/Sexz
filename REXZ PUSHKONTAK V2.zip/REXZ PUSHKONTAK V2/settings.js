const fs = require('fs');
const chalk = require('chalk');

//// ============================
//// • Credits : Rexzofficial
//// • Contact : https://wa.me/6285194293586
//// • Channel YouTube : https://youtube.com/@rexz.official?si=GK3vZza3W0QeFS-t
//// ============================


//~~~~~~~~~< GLOBAL SETTINGS >~~~~~~~~~\\

global.owner = ['6285194293586']
global.ownerUtama = "6285194293586"
global.namaOwner = "REXZ OFFICIAL 👑"
global.packname = 'Bot Pushkontak'
global.botname = '𝙍𝙀𝙓𝙕 𝙊𝙁𝙁𝙄𝘾𝙄𝘼𝙇'
global.namasc = 'SC REXZ PUSHKONTAK V2'
global.version = '0.0.1' // JANGAN UBAH BIAR GA EROR 
global.bylis = '6.7.7' // JANGAN UBAH BIAR GA EROR 
global.tempatDB = 'database.json' // JANGAN UBAH BIAR GA EROR 
global.pairing_code = true

global.linkOwner = "https://wa.me/6285194293586"
global.linkSaluran = "https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S"
global.idChannel = "120363390124370664@newsletter"
global.nameChannel = "REXZ OFFICIAL 👑 [ Testimoni ]"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 4000
global.delayPushkontak = 8000
//==============================================
global.dana = "BLUM ADA"
global.ovo = "BLUM ADA"
global.gopay = "BELUM ADA"
global.qris = "https://qu.ax/uJdUc.jpg"


global.mess = {
	owner: "  \`</> [ Owner Only! ]\`\n- Fitur Ini Hanya Untuk Ownerbot!",
	admin: "  \`</> [ Admin Only! ]\`\n- Fitur Ini Hanya Untuk Admin!",
	botAdmin: "  \`</> [ Bot Admin! ]\`\n- Bot Bukan Admin!",
	group: "  \`</> [ Group Only! ]\`\n- Fitur Ini Hanya Untuk Dalam Grup!",
	private: "  \`</> [ Private Only! ]\`\n- Fitur Ini Hanya Untuk Private Chat!",
	prem: "  \`</> [ Premium Only! ]\`\n- Fitur Ini Hanya Untuk Pengguna Premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}
//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});