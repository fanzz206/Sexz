//// ============================
//// • Credits : Rexzofficial
//// • Contact : https://wa.me/6285194293586
//// • Channel YouTube : https://youtube.com/@rexz.official?si=GK3vZza3W0QeFS-t
//// ============================


process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('node-yt-dl');
const speed = require('performance-now');
const moment = require('moment-timezone');
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))
const list = JSON.parse(fs.readFileSync("./database/list.json"))
const { LoadDataBase } = require('./src/message');
const { TelegraPh, UguuSe } = require('./lib/uploader');
const { toAudio, toPTT, toVideo } = require('./lib/converter');
const { imageToWebp, videoToWebp, writeExif } = require('./lib/exif');
const { chatGpt, tiktokDl, facebookDl, instaDl, instaDownload, instaStory, ytMp4, ytMp3, allDl, Ytdl, cekKhodam } = require('./lib/screaper');
const { pinterest, pinterest2, wallpaper, wikimedia, quotesAnime, happymod, umma, ringtone, styletext, ssweb, igstalk, tts, remini, mediafire } = require('./lib/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, ucapan, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR } = require('./lib/function');
const uploadImage = require('./lib/uploadImage')


module.exports = rexzbot = async (rexzbot, m, chatUpdate, store) => {
	try {
await LoadDataBase(rexzbot, m)
const botNumber = await rexzbot.decodeJid(rexzbot.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = "."
const isCmd = body.startsWith(prefix) ? true : false
const from = m.key.remoteJid
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const isCreator = isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const sender = m.key.fromMe ? (rexzbot.user.id.split(':')[0]+'@s.whatsapp.net' || rexzbot.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const reseller = JSON.parse(fs.readFileSync("./database/reseller.json"))
const isReseller = reseller.includes(m.sender)

///============== [ MESSAGE ] ================
if (isCmd && !m.isBaileys) {
console.log(
chalk.black.bgWhite('[ Command ]:'),chalk.white.bold(prefix+command) + '\n' + chalk.black.bgWhite('[ Sender ]:'),chalk.white.bold(m.sender) + '\n' + chalk.black.bgWhite('[ Type Chat ]:'),chalk.white.bold(m.isGroup ? "Group Chat" : "Private Chat") + '\n\n'
)}

//============= [ FAKEQUOTED ] ===============
const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": "REXZ OFFICIAL"}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Bot Pushkontak REXZ OFFICIAL`,jpegThumbnail: ""}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `REXZ OFFICIAL`,jpegThumbnail: ""}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `Payment By REXZ OFFICIAL`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By Reza`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `REXZ OFFICIAL`,jpegThumbnail: ""}}}

var ppuser
try {
ppuser = await rexzbot.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}

//============ [ EVENT CONTROL ] =============
if (m.isGroup && db.groups[m.chat].antilink) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await rexzbot.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
rexzbot.sendMessage(m.chat, {text: `*- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await rexzbot.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await rexzbot.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}

if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await rexzbot.sendMessage(m.chat, {text: `
*REXZ OFFICIAL Menyediakan 🌟*
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Grup Bebas Promosi*
* *MARKETPLACE REXZ OFFICIAL:*
https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S
* *Channel Testimoni :*
https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S

*👤 Contact REXZ OFFICIAL*
* *WhatsApp Utama :*
+6285194293586
`}, {quoted: null})
}
}


if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await reply(check.respon)
}
}


rexzbot.autoshalat = rexzbot.autoshalat ? rexzbot.autoshalat : {}
let id = m.chat 
if (id in rexzbot.autoshalat) {
return false
}
let jadwalSholat = { shubuh: '04:29', terbit: '05:44', dhuha: '06:02', dzuhur: '12:02', ashar: '14:49', magrib: '17:52', isya: '19:01' }
const datek = new Date((new Date).toLocaleString("en-US", {timeZone: "Asia/Jakarta"}))
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
if (timeNow === waktu && m.isGroup) {
let caption = `
*\`[!] System Notifikasi\`*

Waktu *${sholat}* telah tiba
ambilah air wudhu dan segeralah sholat 

_Pukul *${waktu}* Bogor Cigudeg dan sekitarnya_`
rexzbot.autoshalat[id] = [
await rexzbot.sendMessage(m.chat, {text: caption, mentions: [], contextInfo: { isForwarded: true, forwardingScore: 9999, mentionedJid: [], forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idChannel }}}, {quoted: qlive}),
setTimeout(async () => {
delete rexzbot.autoshalat[m.chat]
}, 50000)]
}}
    


//============== [ FUNCTION ] ================
var example = (teks) => {
return `\n\`</> Contoh Penggunaan :\`\n Ketik *${prefix+command}* ${teks}\n`
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

// Function Reply
const reply = (teks) => { 
rexzbot.sendMessage(from, { text: teks, contextInfo: { 
externalAdReply : { 
showAdAttribution : true, 
title : "CREATOR : REXZ OFFICIAL", 
containsAutoReply : true, 
mediaType : 1, 
thumbnail : fs.readFileSync("./src/media/logo.jpg"),
body: "SC : REXZ PUSHKONTAK V2🪐",
mediaUrl : "https://qu.ax/uJdUc.jpg", 
sourceUrl : "https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S" }}}, { quoted: m }) }

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/logo.jpg") }, { upload: rexzbot.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*REXZ OFFICIAL* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*REXZ OFFICIAL Menyediakan 🌟*

* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Grup Bebas Promosi*
* *MARKETPLACE REXZ OFFICIAL:*
https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S
* *Channel Testimoni :*
https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp3.000

* Ram 2 GB : Rp4.000

* Ram 3 GB : Rp5.000

* Ram 4 GB : Rp6.000

* Ram 5 GB : Rp7.000

* Ram 6 GB : Rp8.000

* Ram 7 GB : Rp9.000

* Ram 8 GB : Rp10.000

* Ram 9 GB : Rp11.000

* Ram 10 GB : Rp12.000

* Ram Unlimited : Rp13.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`,
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `\`LIST VPS DIGITAL OCEHAN BY REXZ\`

* 🚀 RAM 1GB CORE 1 : => *20K* <=
* 🚀 RAM 2GB CORE 1 : => *25K* <=
* 🚀 RAM 2GB CORE 2 : => *30K* <=
* 🚀 RAM 4GB CORE 2 : => *40K* <=
* 🚀 RAM 8GB CORE 4 : => *50K* <=
* 🚀 RAM 16GB CORE 4 : => *70k* <=

=> *_𝙂𝙤𝙤𝙙 𝙌𝙪𝙖𝙡𝙞𝙩𝙮 ✅_* <=
=> *_𝘽𝙚𝙧𝙜𝙖𝙧𝙖𝙣𝙨𝙞 ✅_* <=

\`Bonus Buy Vps\`
- Free Install Panel 1x
- Free Instal Wings/Node 1x
- Free Pasang Egg Bot/Mc
- Free Install Thema Buy Ram 8/16
- Garansi 15 Hari Nego? = Nogar
- Vps On 20 - 30 Hari 
- Garansi Hanya 1x Ambil

\`MINAT? CONTACT DI BAWAH\`
* NOMOR : wa.me//6285194293586

*JIKA DI SINI SLOWRES LANGSUNG BUH NO DI ATAS*

\`TESTI REXZ OFFICIAL REAL\`
* https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qloc})
await rexzbot.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}


//============= [ COMMAND ] ===============
switch (command) {
case "rexz": {
await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
let desc = tanggal(Date.now())
const text12 =`
Hai Kak ${pushname}
Selamat ${ucapan()} dan Selamat Datang!

╔══✪ REXZ OFFICIAL BOT MENU ✪══╗
┃
┃ 📌 Creator: ${namaOwner}
┃ 📞 Number: ${ownerUtama}
┃ 🖥️ Script Name: ${namasc}
┃ 🧩 Script Version: ${version}
┃ 🧠 Baileys Version: ${bylis}
┃ 📅 Hari Ini: ${desc}
┃
╚══════════════════════════╝

╔══════⟪ 🛠️ PUSH MENU ⟫══════╗
┃✅ .pushkontak
┃✅ .pushkontakjd
┃✅ .pushkontak1
┃✅ .pushkontak2
┃✅ .pushkontak3
┃✅ .savekontak
┃✅ .listgc
╚══════════════════════════╝

╔══════⟪ ✉️ JPM MENU ⟫═══════╗
┃📝 .jpm
┃🖼️ .jpm1
┃🧾 .jpmtesti
┃➡️ .jpmslide
┃➡️ .jpmslideht
╚══════════════════════════╝

╔══════⟪ ⚙️ JOB MENU ⟫═══════╗
┃🗂️ .formatned
┃🗂️ .formatjp
┃💰 .feadmin
┃📋 .allrec
┃⏳ .proses
┃✅ .done
╚══════════════════════════╝

╔═════⟪ 🎲 RANDOM MENU ⟫═════╗
┃🖼️ .qc
┃🗣️ .tts
┃🔒 .self
┃🔓 .public
┃📂 .scbot
┃👤 .owner
┃🔗 .tourl
┃🖼️ .tohd
┃🎞️ .sticker
┃💳 .payment
┃🎵 .tiktok
┃🎧 .tiktokmp3
┃📸 .instagram
╚══════════════════════════╝

© 2025 | REXZ OFFICIAL BOT SYSTEM
`
rexzbot.sendMessage(m.chat, { 
	           text: text12,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: "New-Push-REXZ OFFICIAL",
                            body: "creator : REXZ OFFICIAL",
                            thumbnailUrl: "https://qu.ax/uJdUc.jpg",
                            sourceUrl: "https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S",
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: qloc
                    })
      await rexzbot.sendMessage(m.chat, {
                        audio: fs.readFileSync('./all/audio.mp3'),
                        mimetype: 'audio/mpeg',
                        ptt: true
                    }, {
                        quoted: m
                    })
                }
             break
//================================================
case "menu": {
const text12 =`Hai Kak ${pushname}
selamat ${ucapan()}

⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄
⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄
⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄
⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄
⠄⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰
⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤
⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗
⢀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄
⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄
⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄
⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄
⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄
⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴
⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿⣿

\`SCRIPT NEW REXZ OFFICIAL\`
▭▬▭▬▭▬▭▬▭▬▭▬▭
*Grup Update*
https://chat.whatsapp.com/E7mLf5X6UFkJzhdICjL9RR
*Saluran Info Update*
https://whatsapp.com/channel/0029Vay2s9iEFeXfKW5LrE1S
*untuk menampilkan menu*
*silahkan ketik* : \`.rexz\`

*untuk menampilkan tutorial*
*silahkan ketik* : \`.tutor\`

> \`POWER BY : ${namaOwner}\`
`
reply(text12)
}
             break
//================================================
case "tutor": {
const text13 =`
*Hai Kak ${pushname}*  
Selamat ${ucapan()}

┏━━━━━━━━━━━━━━━┓  
    *TUTOR MENU BOT*  
┗━━━━━━━━━━━━━━━┛

\`📤 PUSH GRUP TERBUKA\`  
• Ketik: \`.pushkontak teks\`

\`⏱️ PUSH GRUP TERBUKA + JEDA\`  
• Ketik: \`.pushkontakjd 3000|tekslu\`

\`📇 SAVE KONTAK BEBAS REQUEST\`  
• Ketik: \`.savekontak idgc|nama\`  
• Lihat ID Grup: \`.listgc\`  
• Contoh: \`.savekontak 120363020552458068@g.us|Nama\`

\`🔒 PUSH KONTAK GRUP TERTUTUP\`  
• Ketik: \`.pushkontak1 idgc|teksnya\`  
• Lihat ID Grup: \`.listgc\`  
• Contoh: \`.pushkontak1 120363020552458068@g.us|Save REXZ OFFICIAL\`

\`⏳ PUSH KONTAK TERTUTUP + JEDA\`  
• Ketik: \`.pushkontak2 idgc|jeda|teksnya\`  
• Contoh: \`.pushkontak2 120363020552458068@g.us|1000|Save REXZ OFFICIAL\`

\`✨ PUSH KONTAK + NAMA + JEDA [ NEW ]\`  
• Ketik: \`.pushkontak3 idgc|jeda|namakontak|teksnya\`  
• Contoh: \`.pushkontak3 120363020552458068@g.us|1000|BUYER REXZ|Save REXZ OFFICIAL\`

\`📝 JPM HANYA TEKS\`  
• Ketik: \`.jpm teksnya\`

\`🖼️ JPM TEKS + GAMBAR\`  
• Kirim gambar + teks  
• Ketik: \`.jpm1 teksnya\` atau \`.jpmtesti teksnya\`

\`➡️ JPM SLIDE BUTTON\`  
• Ketik: \`.jpmslide\`

\`➡️ JPM SLIDE + HIDETAG\`  
• Ketik: \`.jpmslideht\`

╭───────◇  
│ *POWERED BY:*  
│  ${namaOwner}
╰───────◇
`
reply(text13)
}
             break
//================================================
case "pushkontak": {
             await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!text) return reply(example("pesannya"))
const teks = text
const jidawal = m.chat
const data = await rexzbot.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await reply(`Memproses *pushkontak*`)
for (let mem of halls) {
if (mem !== botNumber) {
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${namaOwner}\n`
            + 'ORG:Developer;\n'
            + `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
            + 'END:VCARD'
const sentMsg  = await rexzbot.sendMessage(mem, { contacts: { displayName: namaOwner, contacts: [{ vcard }] }})
await rexzbot.sendMessage(mem, {text: teks}, {quoted: sentMsg })
await sleep(global.delayPushkontak)
}}

await rexzbot.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break
//================================================
case "pushkontakjd":
await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (!isCreator) return reply(`Khusus Bang REXZ`)
if (!m.isGroup) return reply(`dalam grup`)
if (!text) return reply(`Penggunaan Salah Silahkan Gunakan Command Seperti Ini\n${prefix+command} jeda|teks`)
await reply(`Memproses *pushkontak*`)
const data = await rexzbot.groupMetadata(m.chat)
const halsss = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
global.tekspushkonv4 = text.split("|")[1]
for (let men of halsss) {
if (/image/.test(mime)) {
media = await rexzbot.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
await rexzbot.sendMessage(men, { image: { url: mem }, caption: global.tekspushkonv4 })
await sleep(text.split("|")[0])
} else {
await rexzbot.sendMessage(men, { text: global.tekspushkonv4 })
await sleep(text.split("|")[0])
                    quoted: qloc
                    }
}
reply(`*Berhasil Pushkontak ✅*\n*Total member ${halsss.length} berhasil dikirim pesan*`)
break
//================================================
case "savekontak": {
if (!isCreator) return reply(mess.owner);

if (!text.includes('|')) {
return reply("*Invalid Format!* Use: `.savekontak idgc|namakontak`\n\n> REXZ OFFICIAL © 2025");
}

const [idgc, contactName] = text.split('|').map(v => v.trim()); // Memisahkan id grup dan nama kontak

if (!idgc || !contactName) {
return reply("*Invalid Input!* Make sure you provide both Group ID and Contact Name.\n\n> REXZ OFFICIAL © 2025");
}

let groupMetadataa;
try {
groupMetadataa = await rexzbot.groupMetadata(`${idgc}`);
} catch (e) {
return reply("*❌ Invalid Group ID!*\nPlease check and try again.\n\n> REXZ OFFICIAL © 2025");
}

const participants = groupMetadataa.participants;
const halls = participants.filter(v => v.id.endsWith('.net')).map(v => v.id);

for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem);
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts));
}
}

try {
const uniqueContacts = [...new Set(contacts)];
let counter = 1; // Inisialisasi nomor urut

const vcardContent = uniqueContacts.map((contact) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${contactName} ${counter}`, // Nama kontak sesuai input
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"",
].join("\n");
counter++;
return vcard;
}).join("");

fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8");
} catch (err) {
return reply(err.toString());
} finally {
if (m.chat !== m.sender) {
await reply(`*✅ Kontak Berhasil Disimpan!*\n\n🌟 File kontak telah dikirim ke obrolan pribadi Anda.\n📂 Total: ${halls.length} Contacts.\n\n> REXZ OFFICIAL © 2025`);
}
await rexzbot.sendMessage(
m.sender,
{
document: fs.readFileSync("./database/contacts.vcf"),
fileName: "contacts.vcf",
caption: `*✅ File Kontak Berhasil Dibuat!*\n📁 Total: *${halls.length}* Contacts.\n\n> REXZ OFFICIAL © 2025`,
mimetype: "text/vcard",
},
{ quoted: qloc }
);

// Bersihkan array kontak dan file
contacts.splice(0, contacts.length);
fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts));
fs.writeFileSync("./database/contacts.vcf", "");
}
}
break
//==============================================
case "pushkontak1": {
if (!isCreator) return reply(mess.owner)
if (!text) return bustomyanakbaik(example("idgc|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgc|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var [idnya, teks] = text.split("|")
var groupMetadataa
try {
groupMetadataa = await rexzbot.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*❌ Invalid Group ID!*\nPlease check and try again.\n\n> REXZ OFFICIAL © 2025")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
const contactName = global.namakontak || "FRESH JEBEH";
await reply(`*⌛ Processing Message Delivery.*\n📤 Sending messages to *${halls.length} contacts*...\n\n> REXZ OFFICIAL © 2025`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
await rexzbot.sendMessage(mem, {text: teks}, {quoted: qloc})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
let counter = 1;

const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${contactName} ${counter}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
counter++;
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`*Successfully Push Contacts! ✅*\n\n🌟 File kontak telah dikirim ke obrolan pribadi Anda\n📂 Totals: ${halls.length} Contacts.\n\n> REXZ OFFICIAL © 2025`)
await rexzbot.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `✅ *File Kontak Berhasil Dibuat!*\n📁 Totals: *${halls.length}* Contacts.\n\n> REXZ OFFICIAL © 2025`, mimetype: "text/vcard", }, { quoted: qloc })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break
//==============================================
case "pushkontak2": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return reply("*❌ Invalid Group ID!*\nPlease check and try again.\n\n> REXZ OFFICIAL © 2025")
if (isNaN(delay)) return reply("*❌ Invalid Delay Format!*\n⏱️ Please use the correct format and try again.\n\n> REXZ OFFICIAL © 2025")
if (!teks) return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await rexzbot.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*❌ Invalid Group ID!*\nPlease check and try again.\n\n> REXZ OFFICIAL © 2025")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
const contactName = global.namakontak || "FRESH JEBEH";
await reply(`*⌛ Processing Message Delivery.*\n📤 Sending messages to *${halls.length} contacts*...\n\n> REXZ OFFICIAL © 2025`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
await rexzbot.sendMessage(mem, {text: teks}, {quoted: qloc})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
let counter = 1;

const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${contactName} ${counter}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
counter++;
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`*Berhasil Mendorong Kontak! ✅*\n\n🌟 Berkas kontak telah dikirim ke obrolan pribadi Anda..\n📂 Totals: ${halls.length} Contacts.\n\n> REXZ OFFICIAL © 2025`)
await rexzbot.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `✅ *Contact File Created Successfully!*\n📁 Totals: *${halls.length}* Contacts.\n\n> REXZ OFFICIAL © 2025`, mimetype: "text/vcard", }, { quoted: qloc })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break
//==============================================
case "pushkontak3": {
if (!isCreator) return reply(mess.owner)

// Memeriksa format perintah
if (!text) return reply(example("idgc|jeda|namakontak|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgc|jeda|namakontak|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))

var idnya = text.split("|")[0]         // ID grup
var delay = Number(text.split("|")[1]) // Jeda
var contactName = text.split("|")[2]   // Nama kontak
var teks = text.split("|")[3]          // Pesan yang dikirim

// Memeriksa format dan validasi input
if (!idnya.endsWith("@g.us")) return reply("*❌ Invalid Group ID!*\nPlease check and try again.\n\n> REXZ OFFICIAL © 2025")
if (isNaN(delay)) return reply("*❌ Invalid Delay Format!*\n⏱️ Please use the correct format and try again.\n\n> REXZ OFFICIAL © 2025")
if (!contactName || !teks) return reply("*Contoh Command :*\n.pushkontak3 idgc|jeda|namakontak|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")

var groupMetadataa
try {
groupMetadataa = await rexzbot.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*❌ Invalid Group ID!*\nPlease check and try again.\n\n> REXZ OFFICIAL © 2025")
}

const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)

// Mengirimkan notifikasi ke owner
await reply(`*⌛ Memproses Pengiriman Pesan.*\n📤 Mengirim pesan ke *${halls.length} contacts*...\n\n> REXZ OFFICIAL © 2025`)

// Mengirim pesan ke setiap kontak
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
await rexzbot.sendMessage(mem, { text: teks }, { quoted: qloc })
await sleep(Number(delay))
}
}

try {
// Membuat file vCard dengan nama yang diberikan oleh user
const uniqueContacts = [...new Set(contacts)]
let counter = 1;

const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${contactName} ${counter}`, // Menggunakan nama kontak dari input user
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"",
].join("\n")
counter++;
return vcard
}).join("")

fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
return m.reply(err.toString())
} finally {
// Mengirimkan hasil ke pengguna
if (m.chat !== m.sender) await reply(`*Berhasil Mendorong Kontak! ✅*\n\n🌟 File kontak telah dikirim ke obrolan pribadi Anda\n📂 Totals: ${halls.length} Contacts.\n👤 nama contacts : ${contactName}\n\n> REXZ OFFICIAL © 2025`)

await rexzbot.sendMessage(
m.sender,
{
document: fs.readFileSync("./database/contacts.vcf"),
fileName: "contacts.vcf",
caption: `✅ *File Kontak Berhasil Dibuat!*\n📁 Totals: *${halls.length}* Contacts.\n👤 nama contacts : ${contactName}\n\n> REXZ OFFICIAL © 2025`,
mimetype: "text/vcard",
},
{ quoted: qloc }
)

// Reset kontak dan file setelah selesai
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}
}
break
//==============================================
case "listgc": case "cekidgc": case"listgrup": {
if (!isCreator) return reply(mess.owner)
await rexzbot.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
let gcall = Object.values(await rexzbot.groupFetchAllParticipating().catch(_=> null))
let listgc = '\n'
await gcall.forEach((u, i) => {
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
rexzbot.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: await getBuffer(ppuser), title: `${gcall.length} Group Chat`, body: `© ${namaOwner}`,  sourceUrl: global.linkSaluran, previewType: "PHOTO"}}}, {quoted: qtext})
}
break
//==============================================
case "jpm": {
if (!isCreator) return reply(mess.owner)
await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (!q) return reply(example("teksnya"))
let allgrup = await rexzbot.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await rexzbot.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await rexzbot.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break
//==============================================
case "jpm1": {
if (!isCreator) return reply(mess.owner)
await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (!/image/.test(mime)) return reply(example("teksnya dengan balas/kirim foto"))
let image = await rexzbot.downloadAndSaveMediaMessage(qmsg)
let total = 0
let getGroups = await rexzbot.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
reply(`Memproses Mengirim Pesan Teks & Foto Ke *${usergc.length} Grup*`)
for (let jid of usergc) {
try {
rexzbot.sendMessage(jid, {image: await fs.readFileSync(image), caption: text, contextInfo: {forwardingScore: 1,
isForwarded: true}}, {quoted: qloc})
total += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(image)
reply(`Berhasil Mengirim Postingan Ke *${total} Grup*`)
}
break
//==============================================
case "jpmtesti": {
if (!isCreator) return reply(mess.owner)
await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (!/image/.test(mime)) return reply(example("teks dengan mengirim foto"))
const allgrup = await rexzbot.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await rexzbot.downloadAndSaveMediaMessage(qmsg)
await reply(`Memproses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await rexzbot.sendMessage(i, {image: await fs.readFileSync(rest), caption: teks, contextInfo: { isForwarded: true, mentionedJid: [m.sender], businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: global.namaSaluran, newsletterJid: global.idSaluran }}}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await rexzbot.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break
//==============================================
case "jpmslide": {
if (!isCreator) return reply(mess.owner)
await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
let allgrup = await rexzbot.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await rexzbot.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break
//==============================================
case "jpmslidehidetag": case "jpmslideht": {
await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (!isCreator) return reply(mess.owner)
let allgrup = await rexzbot.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await rexzbot.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break
//==============================================
case "tt": case "tiktok": {
if (!isCreator) return reply(mess.prem)
if (!text) return reply(example("url"))
if (!text.startsWith("https://")) return reply(example("url"))
await tiktokDl(q).then(async (result) => {
await rexzbot.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return reply("Error!")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: rexzbot.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Tiktok Downloader ✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await rexzbot.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await rexzbot.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*`}, {quoted: m})
}
}).catch(e => console.log(e))
await rexzbot.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
//==============================================
case "tiktokmp3": case "ttmp3": {
if (!isCreator) return reply(mess.prem)
if (!text) return reply(example("linknya"))
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
await rexzbot.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await tiktokDl(text).then(async (res) => {
if (!res.status) return reply("Error! Result Not Found")
await rexzbot.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await rexzbot.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => reply("Error! Result Not Found"))
}
break
//==============================================
case "formatjp": case "jp": {
const text14 =`
📦 *FORMAT JASPOST ${namaOwner}*  
🟢 JUAL / NEED

• *JENIS / ITEM*  :  
• *SPEK*          :  
• *LOGIN*         :  
• *NO WA*         :  
• *HARGA*         :  
• *REKBER / MC*   :  

⚠️ *WAJIB MENGGUNAKAN REKBER / MC ${namaOwner} STORE*  
Agar aman & terhindar dari penipuan!

*NO REKBER (OWNER) STORE:*  
wa.me/${ownerUtama}

*SELain nomor di atas = CLONE / PENIPU!*

💬 Tawar-menawar?  
*Langsung chat nomor pemilik akun / yang need akun.*

🛡️ *BE SMART BUYER AND SELLER!*
`
m.reply(text14)
}
             break
//==============================================
case "formatned": case "need": {
const text15 =`
📦 *FORMAT JASPOST ${namaOwner}*  
🟢 JUAL / NEED

• *JENIS / ITEM*  :  
• *SPEK*          :  
• *LOGIN*         :  
• *NO WA*         :  
• *HARGA*         :  
• *REKBER / MC*   :  

⚠️ *WAJIB MENGGUNAKAN REKBER /MC ${namaOwner} STORE*  
Agar aman & terhindar dari penipuan!

*NO REKBER (OWNER) STORE:*  
wa.me/${ownerUtama}

*SELain nomor di atas = CLONE / PENIPU!*

💬 Tawar-menawar?  
*Langsung chat nomor pemilik akun / yang need akun.*

🛡️ *BE SMART BUYER AND SELLER!*
`
m.reply(text15)
}
             break
//==============================================
case "feadmin": {
const text16 =`
*『 FEE ADMIN ${namaOwner} 』*

💳 *PAYMENT VIA:*  
OVO • GOPAY • DANA • QRIS

╭───「 *FEE LIST* 」───⬣
│ 0K – 10K     = 3K  
│ 11K – 50K   = 5K  
│ 51K – 100K  = 10K  
│ 101K – 150K = 15K  
│ 151K – 200K = 20K  
│ 201K – 250K = 25K  
│ 251K – 300K = 30K  
│ 301K – 400K = 35K  
│ 401K – 500K = 40K  
│ *DAN SETERUSNYA...*
╰────────────────⬣

⚠️ *NOTE:*  
Jika transaksi *dibatalkan*, *fee tetap terpotong*.

*FEE MAHAL?*  
Gapapa mahal, *asalkan AMANAH!*  
Daripada murah tapi *dibawa kabur!*
`
m.reply(text16)
}
break
//==============================================
case "proses": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("panel"))
const msg = {
text: `*Dana Masuk ✅*
📦 ${text}

_*© 2025 - REXZ OFFICIAL*_`
}
await rexzbot.sendMessage(m.chat, msg, {quoted: null})
}
break
//==============================================
case "done": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("panel"))
const msg = {
text: `*Transaksi Done ✅*
📦 ${text}

_*© 2025 - REXZ OFFICIAL*_`
}
await rexzbot.sendMessage(m.chat, msg, {quoted: null})
}
break
//==============================================
case 'alrecc':
  case 'alrec':
  case 'allrecc':
  case 'alrecc':
  case 'allrec':{
let riki4 = `
*『 REKAM LAYAR SEKARANG! 』*
==============================
✅ *INSTRUKSI WAJIB:*  
1. Hapus *SEMUA PESAN GMAIL*  
2. Kosongkan *SEMUA SAMPAH GMAIL*  
3. Hapus *AKUN FACEBOOK* dari perangkat  
4. Hapus *AKUN GMAIL* (jika memungkinkan)  
5. Logout *Free Fire* dari semua perangkat

⚠️ *WAJIB REKAM SAAT PROSES!*

*— BY ${namaOwner}*
`
m.reply(riki4)
}
break
//==============================================
case "tts": {
if (!text) return reply(example("Hallo saya manusia"))
if (text.length >= 300) return reply("Jumlah huruf harus di bawah 300!")
reply(mess.wait)
let id = 'id_001'
try {
const { data } = await axios.post("https://tiktok-tts.weilnet.workers.dev/api/generation", {
    "text": text,
    "voice": id
})
rexzbot.sendMessage(m.chat, { audio: Buffer.from(data.data, "base64"), mimetype: "audio/mp4" }, {quoted: m})
} catch (e) {
return reply(e.toString())
}
}
break
//==============================================
case 'tourl': {
if (!isReseller && !isCreator) return reply(mess.prem)
await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) return reply('Tidak ada media yang ditemukan')
  let media = await q.download()
  let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
  let fileSizeLimit = 5 * 1024 * 1024 
  if (media.length > fileSizeLimit) {
    return reply(`Ukuran media tidak boleh melebihi 5MB`)
  }
  let link = await (isTele ? uploadImage : uploadFile)(media)
  reply(`▧ BERHASIL CUY SC BY REXZ OFFICIAL ✅

│ • ${link}

${media.length} byte(s)
${isTele ? '(Tidak Ada Tanggal Kedaluwarsa)' : '(Expired 24 hours)'}`)
}
break
//==============================================
case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
var image = await rexzbot.downloadAndSaveMediaMessage(qmsg)
await rexzbot.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break
//==============================================
case "tohd": case "hd": {
if (!isCreator) return reply(mess.prem)
await rexzbot.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!/image/.test(mime)) return reply(example("dengan kirim/reply foto"))
let foto = await rexzbot.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await rexzbot.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break
//==============================================
case "qc": {
        await rexzbot.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (!quoted){
const getname = await rexzbot.getName(mentionUser[0])
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#000000",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": getname,
"photo": {
"url": ppuser
}
},
"text": quotedMsg.chats,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
rexzbot.sendAsSticker(from, buffer, m, opt)
});
} else if (q) {
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#000000",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": pushname,
"photo": {
"url": ppuser
}
},
"text": q,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
rexzbot.sendAsSticker(from, buffer, m, opt)
});
} else {
reply(`Kirim perintah ${prefix+command} text atau reply pesan dengan perintah ${prefix+command}`)
}
}
break
//==============================================
case "instagram": case "igdl": case "ig": {
if (!isReseller && !isCreator) return reply(mess.prem)
if (!text) return reply(example("linknya"))
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
await rexzbot.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://aemt.uk.to/download/igdl?url=${text}`).then(async (res) => {
if (!res.status) return reply("Error! Result Not Found")
await rexzbot.sendMessage(m.chat, {video: {url: res.result[0].url}, mimetype: "video/mp4", caption: "*Instagram Downloader ✅*"}, {quoted: m})
await rexzbot.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => reply("Error! Result Not Found"))
}
break
//==============================================
case "pay": case "payment": {
if (!isCreator) return reply(mess.owner)
await rexzbot.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
let imgdana = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/dana.jpg")}, { upload: rexzbot.waUploadToServer })
let imgovo = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/ovo.jpg")}, { upload: rexzbot.waUploadToServer })
let imggopay = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/gopay.jpg")}, { upload: rexzbot.waUploadToServer })
let imgqris = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/qris.jpg")}, { upload: rexzbot.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "Pilih Payment Pembayaran"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgdana
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Dana Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.dana}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgovo
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"OVO Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.ovo}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imggopay
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Gopay Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.gopay}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgqris
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\" QRIS Payment\",\"url\":\"${global.qris}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}
]
})
})}
}}, {userJid: m.sender, quoted: qtoko})
await rexzbot.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}
break
//============== [ OWNERMENU ] ==============
case "developerbot": case "owner": {
await rexzbot.sendContact(m.chat, [global.ownerUtama], null)
}
case "self": {
if (!isCreator) return
rexzbot.public = false
reply("Berhasil Beralih Ke Mode Self")
}
break
case "public": {
if (!isCreator) return
rexzbot.public = true
reply("Berhasil Beralih Ke Mode Public")
}
break
case "scbot": case "sc": 
case "scriptbot": {
let teks = `*# Script REXZ PUSHKONTAK V2🪐*
Script Ini Di Jual Dengan Harga Rp10.000
Jika Berminat Silahkan Chat Developer Bot Ini

*Contacv1t :* https://wa.me/6285194293586
*_© Credits By REXZ OFFICIAL_*`
rexzbot.relayMessage(m.chat,  {requestPaymentMessage: {currencyCodeIso4217: 'IDR', amount1000: 25000000, requestFrom: m.sender, noteMessage: { extendedTextMessage: { text: teks, contextInfo: { externalAdReply: { showAdAttribution: true}}}}}}, {})
}
break
//================ [ DEFAULT ] ================
default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}}

if (m.text.toLowerCase() == "bot") {
reply("Bot Online ✅")
}

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}}

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return reply(`${err}`)
if (stdout) return reply(stdout)
})
}


}} catch (err) {
console.log(util.format(err));
rexzbot.sendMessage(obj + "@s.whatsapp.net", {text: '*Fitur Error Terdeteksi*\n\n*Log error :*\n' + util.format(err), contextInfo: { isForwarded: true }}, {quoted: m})
}}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});