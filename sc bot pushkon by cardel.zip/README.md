 █████╗ ██████╗ ██╗  ██╗ █████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔══██╗
███████║██████╔╝█████╔╝ ███████║
██╔══██║██╔══██╗██╔═██╗ ██╔══██║
██║  ██║██║  ██║██║  ██╗██║  ██║
╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝

Credit script:
Arka
Ida Sang Hyang Widhi ( My God )
TamaRyuichi
Fahri
Xal Dev
dll

THANKS FOR BUYING MY SCRIPT

                                